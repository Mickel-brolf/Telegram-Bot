const express = require('express');
const fs = require('fs');
const cors = require('cors');
const bodyParser = require('body-parser');
const app = express();
const PORT = 3000;

app.use(cors());
app.use(bodyParser.json());
app.use(express.static('public'));

// Load all messages
app.get('/api/messages', (req, res) => {
  const data = JSON.parse(fs.readFileSync('./message.json', 'utf8'));
  res.json(data);
});

// Add or update a message
app.post('/api/messages', (req, res) => {
  const { date, message } = req.body;
  const messages = JSON.parse(fs.readFileSync('./message.json', 'utf8'));
  messages[date] = message;
  fs.writeFileSync('./message.json', JSON.stringify(messages, null, 2), 'utf8');
  res.json({ status: 'Message saved' });
});

app.listen(PORT, () => console.log(`📡 Admin dashboard running at http://localhost:${PORT}`));
