const { Telegraf } = require('telegraf');
const fs = require('fs');

// ✅ Replace with your actual token
const bot = new Telegraf('7631618968:AAEJqd4opJviSlu-9Y8Z1hD3XE3xf2274DI');

// ✅ Load messages from JSON file
let messages = {};
try {
  messages = JSON.parse(fs.readFileSync('./messages.json', 'utf8'));
} catch (error) {
  console.error('❌ Error reading messages.json:', error);
}

// ✅ /start command
bot.start((ctx) => {
  ctx.reply('🌹 Welcome to the Secret Love Message Bot!\n\nSend today’s *passcode* to unlock your message 💌', {
    parse_mode: 'Markdown'
  });
});

// ✅ Handle text (passcode input)
bot.on('text', async (ctx) => {
  const today = new Date().toISOString().split('T')[0];
  const input = ctx.message.text.trim();

  const message = messages[today];

  if (!message) {
    return ctx.reply('⏳ No message scheduled for today.');
  }

  const { passcode, text, quote, media_type, media_url } = message;

  if (input === passcode) {
    await ctx.reply(`✅ *Unlocked!*\n\n${text}`, { parse_mode: 'Markdown' });

    if (quote) {
      await ctx.reply(`💬 _${quote}_`, { parse_mode: 'Markdown' });
    }

    if (media_type === 'image' && media_url) {
      await ctx.replyWithPhoto({ url: media_url });
    } else if (media_type === 'voice' && media_url) {
      await ctx.replyWithVoice({ url: media_url });
    } else if (media_type === 'video' && media_url) {
      await ctx.replyWithVideo({ url: media_url });
    }
  } else {
    await ctx.reply('❌ Wrong passcode.\nTry again.');
  }
});

// ✅ Launch bot
bot.launch();
console.log('💌 Love Bot is running...');
